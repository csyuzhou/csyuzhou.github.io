Overall： 10 APPs

Each of the APPs contains Three parts:
	1. the commit messages from GitHub: commit_appName.csv
	2. the user reviews from googleplay: googleplay_appName.csv
	3. the source code of App: appName-master.zip or appName-dev.zip and so on : (The a b c three parts are the content we extracted from the source code using AST.)
	                                 a. the code components of class extracted by AST from the source code: output.json
	                                 b. the filepath of Xml: outputXml.txt
	                                 c. the path of class without Method Declarations: pathsWithoutMethodDeclarations.txt